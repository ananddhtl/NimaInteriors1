<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	{{-- <title>en Projecten:: Nimainteriors.com</title> --}}
	<div style="background-color: white;">
		<title>@yield('title', 'Nimainteriors.com')</title>
	</div>
	{{-- meta data will be also dynamic --}}
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content=""/>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="{{ asset('frontend/assets/images/favicon/favbrt.ico') }}" />

	<!-- Bootstrap & Plugins CSS -->
	<link href="{{asset('frontend/assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{asset('frontend/assets/css/font-awesome.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{asset('frontend/assets/css/owl.carousel.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{asset('frontend/assets/css/owl.theme.default.min.css')}}" rel="stylesheet" type="text/css">
	<link href="{{asset('frontend/assets/css/magnific-popup.css')}}" rel="stylesheet" type="text/css">

	<!-- Custom CSS -->
	<link href="{{asset('frontend/assets/css/style.css')}}" rel="stylesheet" type="text/css">
</head>