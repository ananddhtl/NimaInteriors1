<script src="{{asset('frontend/assets/js/jquery-3.6.0.min.js')}}"></script>

<!-- Bootstrap -->
<script src="{{asset('frontend/assets/js/popper.js')}}"></script>
<script src="{{asset('frontend/assets/js/bootstrap.min.js')}}"></script>

<!-- Plugins -->
<script src="{{asset('frontend/assets/js/scrollreveal.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/parallax.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/waypoints.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/jquery.counterup.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/imgfix.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('frontend/assets/js/jquery.magnific-popup.min.js')}}"></script>

<!-- Global Init -->
<script src="{{asset('frontend/assets/js/custom.js')}}"></script>
{{-- <script>
    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            items: 1, // Number of items to display
            loop: true, // Enable infinite loop
            autoplay: true, // Enable autoplay
            autoplayTimeout: 100, // Autoplay interval in milliseconds (1 second)
            autoplayHoverPause: false, // Do not pause autoplay on mouse hover
            animateOut: 'fadeOutRight', // Animation for slide out
            animateIn: 'fadeInLeft', // Animation for slide in
            smartSpeed: 100, // Animation speed
        });
    });
</script> --}}