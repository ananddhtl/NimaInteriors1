@extends('welcome')
@section('title','change password :: Nimainteriors.com')

@section('content')

<section class="page profile">
    <div class="container">
        <div class="c-account d-flex">
            <div class="left-bar s-opt">
                <ul>
                    <li  data-content="profile" class="active">
                        Profile
                    </li>
                    <li data-content="address">
                        Address
                    </li>
                    <li  data-content="order">
                        Order History
                    </li>
                </ul>
            </div>
            <div class="right-form show-d">
                <div class="profile-setting">
                    <div class="card">
                        <div class="card-header">
                            profile here
                        </div>
                        <div class="card-body">
                            <div id="profile">Content for Profile</div>
                            <div id="address" class="hidden">
                                <form id="addressForm">
                                    <div class="row">
                                        <div class=" form-group">
                                            <label for="street">Street:</label>
                                            <input type="text" id="street" name="street" required>
                                        </div>
                                        <div class=" form-group">
                                            <label for="number">Number:</label>
                                            <input type="text" id="number" name="number" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="bus">Bus:</label>
                                            <input type="text" id="bus" name="bus">
                                        </div>
                                        <div class="form-group">
                                            <label for="postcode">Postcode:</label>
                                            <input type="text" id="postcode" name="postcode" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="city">City:</label>
                                            <input type="text" id="city" name="city" required>
                                        </div>
                                       
                                            <button class="btn btn-secondary" type="submit">Save Address</button>
                                        
                                       
                                    </div>
                                    
                                </form>
                            </div>
                            <div id="order" class="hidden">Content for Order Hisotry</div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
       
    </div>
</section>

@endsection

<script>
    document.addEventListener("DOMContentLoaded", function() {
    const menuItems = document.querySelectorAll('.left-bar ul li');
    const contents = document.querySelectorAll('.right-form div');

    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            const contentId = this.getAttribute('data-content');
            contents.forEach(content => {
                if (content.id === contentId) {
                    content.classList.remove('hidden');
                } else {
                    content.classList.add('hidden');
                }
            });
            menuItems.forEach(item => {
                item.classList.remove('active');
            });
            this.classList.add('active');
             // If the clicked menu item is "Address", ensure form group is shown
             if (contentId === 'address') {
                const rows = document.getElementById('addressForm').querySelectorAll('.row');
                rows.forEach(row => {
                    row.classList.remove('hidden');
                });
                const formGroups = document.getElementById('addressForm').querySelectorAll('.form-group');
                formGroups.forEach(formGroup => {
                    formGroup.classList.remove('hidden');
                });
            } else {
                const rows = document.getElementById('addressForm').querySelectorAll('.row');
                rows.forEach(row => {
                    row.classList.add('hidden');
                });
                // Hide form group for other content
                const formGroups = document.getElementById('addressForm').querySelectorAll('.form-group');
                formGroups.forEach(formGroup => {
                    formGroup.classList.add('hidden');
                });
            }
        });
    });
    const defaultContentId = document.querySelector('.left-bar li.active').getAttribute('data-content');
    document.getElementById(defaultContentId).classList.remove('hidden');

      // If the default active menu item is "Address", ensure form group is shown
      if (defaultContentId === 'address') {
        const rows = document.getElementById('addressForm').querySelectorAll('.row');
                rows.forEach(row => {
                    row.classList.remove('hidden');
                });
        const formGroups = document.getElementById('addressForm').querySelectorAll('.form-group');
        formGroups.forEach(formGroup => {
            formGroup.classList.remove('hidden');
        });
    }
});

    </script>