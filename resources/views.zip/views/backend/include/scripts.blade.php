
<script src="{{asset('backend/assets/js/vendor.min.js')}}"></script>
<script src="{{asset('backend/assets/js/app.js')}}"></script>

<!-- Knob charts js -->
<script src="{{asset('backend/assets/libs/jquery-knob/jquery.knob.min.js')}}"></script>

<!-- Sparkline Js-->
<script src="{{asset('backend/assets/libs/jquery-sparkline/jquery.sparkline.min.js')}}"></script>

<script src="{{asset('backend/assets/libs/morris.js/morris.min.js')}}"></script>

<script src="{{asset('backend/assets/libs/raphael/raphael.min.js')}}"></script>

<!-- Dashboard init-->
<script src="{{asset('backend/assets/js/pages/dashboard.js')}}"></script>

<script src="{{asset('backend/assets/libs/quill/quill.min.js')}}"></script>

<!-- Demo js-->
<script src="{{asset('backend/assets/js/pages/form-quilljs.js')}}"></script>